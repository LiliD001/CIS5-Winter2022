/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Liliana Darch
 * Created on January 10, 2022, 1:55 PM
 * Purpose: Program that display a diamond pattern
 */
 

//System Level Libraries
#include <cstdlib>
#include <iostream> //Input-Output Library
using namespace std;
 
//User Defined Libraries

//Global constants, not Global variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
   
    
    //Initialize Variables
  
    
    //Map the inputs/known to the outputs
    
    
    //Display the outputs
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;
    cout<<" *****"<<endl;
    cout<<"  ***"<<endl;
    cout<<"   *"<<endl;
    
    //Exit the program
    return 0;
}

